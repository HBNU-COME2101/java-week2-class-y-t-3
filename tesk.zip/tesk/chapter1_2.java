package tesk;

public class chapter1_2 {

	public static void main(String[] args) {
		int n = 20201821;
		System.out.println(n+" 홍윤택");

	}

}
