package tesk;

public class chapter1_1 {

	public static void main(String[] args) {
		System.out.println("Hello world!.");
	}

}
