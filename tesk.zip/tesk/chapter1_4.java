package tesk;

import java.util.Scanner;

public class chapter1_4 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("여행지 입력");
		String local1 = scanner.next();
		String local2 = scanner.next();
		System.out.println("인원수 입력");
		int num = scanner.nextInt();
		System.out.println("숙박일 입력");
		int day = scanner.nextInt();
		System.out.println("1인당 항공료 입력");
		int fprice = scanner.nextInt();
		System.out.println("1인당 숙박비 입력");
		int pprice = scanner.nextInt();
		
		double cal =  Math.round(num/2.0);
		int count = (int) Math.round(cal);
		int day2 = day+1;
		int total = num*fprice+pprice*day*count;

		System.out.println(""+num+"명의 "+local1+" "+local2+" "+day+"박 "+day2+"일 여행에는 방이 "+count+"개 필요하며 경비는 "+total+"원입니다.");
	}

}
