package tesk;

import java.util.Scanner;

public class chapter1_6 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("(x1,y1),(x2,y2)의 좌표 입력");
		int x1 = scanner.nextInt();
		int y1 = scanner.nextInt();
		int x2 = scanner.nextInt();
		int y2 = scanner.nextInt();
		
		if(x1>=10 && x2<200 || x2>=10 && x1<200)
			System.out.println("("+x1+","+y1+"),("+x2+","+y2+")사각형은 (10,10)(200,300)사각형에 포함된다");
		else
			System.out.println("("+x1+","+y1+"),("+x2+","+y2+")사각형은 (10,10)(200,300)사각형에 포함되지않는다");
	}

}
