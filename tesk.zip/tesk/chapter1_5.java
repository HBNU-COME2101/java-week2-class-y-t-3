package tesk;

import java.util.Scanner;

public class chapter1_5 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("나이 입력");
		int age = scanner.nextInt();
		
		int a,b,c;
		a=age/10;
		age%=10;
		if(age>=5) {
			b=1;
			c=age-5;
		}
		else {
			b=0;
			c=age;
		}
		int total = a+b+c;
		
		System.out.println("빨간초 "+a+"개, 파란초 "+b+"개 노란초 "+c+"개. 총 "+total+"개가 필요합니다");
	}

}
