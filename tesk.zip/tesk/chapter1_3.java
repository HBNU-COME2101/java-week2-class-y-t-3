package tesk;

import java.util.Scanner;

public class chapter1_3 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("셍일을 입력하세요.");
		int a = scanner.nextInt();
		int y, m ,d;
		
		y=a/10000;
		a%=10000;
		
		m=a/100;
		a%=100;
		
		d=a;

		System.out.println(""+y+"년 "+m+"월 "+d+"일");
	}

}
